# -*- coding: utf-8 -*-
# GNU General Public License v3.0 (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)
''' A list of static data '''

from __future__ import absolute_import, division, unicode_literals

CHANNELS = [
    dict(
        name='Ma tele En Direct',
        label='World',
        description='Tv Live',
        live_stream='http://sphinxroot.com/Main/Menu.m3u',
        logo='https://i.imgur.com/tVUrQP1.png',
        website='https/github/com',
        preset=201,
    ),
]
